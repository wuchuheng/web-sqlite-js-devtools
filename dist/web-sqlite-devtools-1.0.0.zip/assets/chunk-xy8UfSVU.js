const t="icon-state";export{t as I};
